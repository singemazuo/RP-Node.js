/**
 * @author Yinbin Zuo & Adam Crooks
 * @date March 19th, 2019
 */

import App from "./app";

// main entrance
const app = new App();
// starts server and begins listening on the port
app.listen();
