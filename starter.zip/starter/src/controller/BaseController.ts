import express from "express";

class BaseController {

}

export default BaseController;
