declare module "@okta/oidc-middleware";
declare module "mongoose";